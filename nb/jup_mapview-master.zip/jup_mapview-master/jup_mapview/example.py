#!/usr/bin/env python
# coding: utf-8

# Copyright (c) nanangqq.
# Distributed under the terms of the Modified BSD License.

"""
TODO: Add module docstring
"""

from ipywidgets import DOMWidget
from traitlets import Unicode
from ._frontend import module_name, module_version

import json
import geopandas
import pandas
from shapely import wkb

class Mapview(DOMWidget):

    """TODO: Add docstring here
    """
    _model_name = Unicode('ExampleModel').tag(sync=True)
    _model_module = Unicode(module_name).tag(sync=True)
    _model_module_version = Unicode(module_version).tag(sync=True)
    _view_name = Unicode('ExampleView').tag(sync=True)
    _view_module = Unicode(module_name).tag(sync=True)
    _view_module_version = Unicode(module_version).tag(sync=True)
    
    value = Unicode('test').tag(sync=True)
    data = Unicode('').tag(sync=True)
    map_key = Unicode('').tag(sync=True)
    
    def __init__(self, map_key='') -> None:
        super().__init__()
        self.map_key = map_key
    
    def df_to_data(self, df, geom_column_name):
        # print(df)
        if type(df)==geopandas.geodataframe.GeoDataFrame or pandas.pandas.core.frame.DataFrame:
            if geom_column_name in df.columns:
                feature_collection = {'type':'FeatureCollection', 'features':[]}
                if '__geo_interface__' not in dir(df[geom_column_name].iloc[0]):
                    df[geom_column_name] = df[geom_column_name].apply(lambda byte_str: wkb.loads(byte_str, hex=True))
                prop_names = [col for col in df.columns if col != geom_column_name]
                df.apply(lambda row: feature_collection['features'].append({
                    'type': 'Feature',
                    'geometry': row[geom_column_name].__geo_interface__,
                    'properties': {
                        prop_name: row[prop_name] for prop_name in prop_names
                    }
                }), axis=1)
                
                self.data = json.dumps(feature_collection)
            
            else:
                print(f'geometry column "{geom_column_name}" does not exists.')
        else:
            # self.data = json.dumps(df)
            print('df should be DataFrame or GeoDataFrame')
        
        return None

    def set_map_key(self, key):
        self.map_key = key