import { createStore, combineReducers } from 'redux'

const data = (
  state = {},
  action: { type: 'data/place' | 'data/clear'; payload: object },
) => {
  switch (action.type) {
    case 'data/place':
      return { ...action.payload }
    case 'data/clear':
      return {}
    default:
      return state
  }
}

const mapKey = (
  state = '',
  action: { type: 'mapKey/set' | 'mapKey/clear'; payload: string },
) => {
  switch (action.type) {
    case 'mapKey/set':
      return action.payload
    case 'mapKey/clear':
      return ''

    default:
      return state
  }
}

const map = (
  state = '',
  action: { type: 'map/store' | 'map/clear'; payload: { map: L.Map } },
) => {
  switch (action.type) {
    case 'map/store':
      return action.payload.map
    case 'map/clear':
      return ''

    default:
      return state
  }
}

const rootReducer = combineReducers({
  data,
  mapKey,
  map,
})

const store = createStore(rootReducer)

export type RootState = ReturnType<typeof store.getState>
export default store
