// Copyright (c) nanangqq
// Distributed under the terms of the Modified BSD License.

import {
  DOMWidgetModel,
  DOMWidgetView,
  ISerializers,
} from '@jupyter-widgets/base'

// import L from 'leaflet'

import { MODULE_NAME, MODULE_VERSION } from './version'

import root from './root'
import store from './store'

// Import the CSS
// import '../css/widget.css'
import '../css/leaflet.css'

export class ExampleModel extends DOMWidgetModel {
  defaults() {
    return {
      ...super.defaults(),
      _model_name: ExampleModel.model_name,
      _model_module: ExampleModel.model_module,
      _model_module_version: ExampleModel.model_module_version,
      _view_name: ExampleModel.view_name,
      _view_module: ExampleModel.view_module,
      _view_module_version: ExampleModel.view_module_version,
      value: 'Hello World',
      data: '',
      map_key: '',
    }
  }

  static serializers: ISerializers = {
    ...DOMWidgetModel.serializers,
    // Add any extra serializers here
  }

  static model_name = 'ExampleModel'
  static model_module = MODULE_NAME
  static model_module_version = MODULE_VERSION
  static view_name = 'ExampleView' // Set to null if no view
  static view_module = MODULE_NAME // Set to null if no view
  static view_module_version = MODULE_VERSION
}

export class ExampleView extends DOMWidgetView {
  render() {
    const mapEl = document.createElement('div')
    mapEl.id = `mapRoot_${new Date().getTime()}`
    mapEl.setAttribute('style', 'width:100%;height:600px')
    this.el.appendChild(mapEl)
    this.map_key_changed()

    setTimeout(() => {
      root(mapEl.id)
      // console.log('hello, react')
      // console.log('Initial state: ', store.getState())
      // const unsubscribe = store.subscribe(() =>
      //   console.log('State after dispatch: ', store.getState()),
      // )
      // this.value_changed()
    }, 500)
    this.model.on('change:value', this.value_changed, this)
    this.model.on('change:data', this.data_changed, this)
    this.model.on('change:map_key', this.map_key_changed, this)
  }

  value_changed() {
    console.log(this.model.get('value'))
  }

  data_changed() {
    let data

    try {
      data = this.model.get('data')
      data = JSON.parse(data)
    } catch (error) {
      console.log(error)
    }

    store.dispatch({ type: data ? 'data/place' : 'data/clear', payload: data })
  }

  map_key_changed() {
    const mapKey = this.model.get('map_key')
    store.dispatch({
      type: mapKey ? 'mapKey/set' : 'mapKey/clear',
      payload: mapKey,
    })
  }
}
