export type Pnu = string
export type Pnus = {
  [index: string]: boolean
}
export type GeoJsonObject = GeoJSON.GeoJsonObject
export type LandDatum = { st_asgeojson: GeoJsonObject; pnu: Pnu }
export type LandData = LandDatum[]

// const pnu: Pnu = '1168010600109450010'
// const pnus: Pnus = {
//   [pnu]: true,
// }

// console.log(pnus)
