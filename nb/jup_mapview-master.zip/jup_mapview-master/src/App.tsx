import React, { useEffect, useState, useCallback } from 'react'
import L, { LeafletMouseEvent } from 'leaflet'
import styled from 'styled-components'

import { Pnus, LandData, GeoJsonObject } from './types'
import {
  initOption,
  Stadia_AlidadeSmooth,
  Stadia_AlidadeSmoothDark,
  osm,
} from './mapInit'
// import { useAppSelector } from './data'
import { useDispatch, useSelector } from 'react-redux'
import { RootState } from './store'

const MapBox = styled.div`
  width: 100%;
  height: 100vh;
  /* height: 50vh; */
  position: relative;
`

function App() {
  const [mapId, setMapId] = useState<string>()
  const [dataLayer, setDataLayer] = useState<L.Layer>()

  const data = useSelector((state: RootState) => state)
  const dispatch = useDispatch()

  // 초기 지도 세팅
  useEffect(() => {
    const id = `map_${new Date().getTime()}`
    setMapId(id)
  }, [])

  useEffect(() => {
    if (mapId) {
      if (data.map) {
        const oldMap: any = data.map
        oldMap.remove()
        dispatch({ type: 'map/clear', payload: {} })
      }

      const lmap = L.map(mapId, initOption)
      dispatch({ type: 'map/store', payload: { map: lmap } })

      // console.log(data.mapKey)
      // lmap.eachLayer(layer=>{})
      // lmap.removeLayer()

      if (data.mapKey) {
        Stadia_AlidadeSmoothDark(data.mapKey).addTo(lmap)
      } else {
        osm.addTo(lmap)
      }
    }
  }, [mapId])
  // 초기 지도 세팅 끝

  useEffect(() => {
    // console.log('from App', data)
    // console.log(map)
    try {
      const bound = L.geoJSON(data.data as GeoJsonObject).getBounds()
      // console.log(bound)
      const map: any = data.map

      if (dataLayer) {
        map.removeLayer(dataLayer)
      }

      const d = L.geoJSON(data.data as GeoJsonObject, {
        style: {
          color: 'orange',
          weight: 1,
        },
      })
        .bindTooltip((layer: any) => {
          // console.log(layer)
          return Object.keys(layer.feature.properties)
            .map(
              propName =>
                `<strong>${propName}</strong>: ${layer.feature.properties[propName]}`,
            )
            .join('</br>')
        })
        .addTo(map)
      setDataLayer(d)

      map.fitBounds(bound)
    } catch (error) {
      console.log(error)
    }
  }, [data])

  return mapId ? <MapBox id={mapId} /> : <></>
}

export default App
