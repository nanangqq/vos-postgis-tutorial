
jup_mapview
=====================================

Version: |release|

A Custom Jupyter Widget Library


Quickstart
----------

To get started with jup_mapview, install with pip::

    pip install jup_mapview

or with conda::

    conda install jup_mapview


Contents
--------

.. toctree::
   :maxdepth: 2
   :caption: Installation and usage

   installing
   introduction

.. toctree::
   :maxdepth: 1

   examples/index


.. toctree::
   :maxdepth: 2
   :caption: Development

   develop-install


.. links

.. _`Jupyter widgets`: https://jupyter.org/widgets.html

.. _`notebook`: https://jupyter-notebook.readthedocs.io/en/latest/
